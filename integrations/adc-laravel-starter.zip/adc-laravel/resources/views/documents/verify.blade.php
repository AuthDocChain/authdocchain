@extends('layouts.app')
@section('title','Verify')
@section('content')

<div class="page-header">
    <h1 class="page-title">Verify a document</h1>
    <p class="page-sub">Check the authenticity of any certified document</p>
</div>

{{-- Tab switcher --}}
<div class="card" style="margin-bottom:16px;">
    <div class="tabs" id="tabs">
        <button type="button" class="tab on" onclick="switchTab('file')">Upload document</button>
        <button type="button" class="tab" onclick="switchTab('ref')">Reference ID</button>
    </div>

    @if($errors->any())
    <div class="alert alert-error" style="margin-bottom:14px;">
        <span class="alert-icon">✕</span>
        <div>@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>
    </div>
    @endif

    {{-- File form --}}
    <form method="POST" action="{{ route('documents.verify.post') }}" enctype="multipart/form-data" id="form-file">
        @csrf
        <input type="hidden" name="mode" value="file">
        <div class="fg">
            <label for="doc-file">Drop the document here to verify its authenticity</label>
            <input type="file" id="doc-file" name="document" accept=".pdf,.png,.jpg,.jpeg">
            <div class="tip">
                The document fingerprint is computed on your server — the file is never transmitted to a third party.
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg" onclick="this.textContent='Verifying…'">Verify document →</button>
    </form>

    {{-- Reference form --}}
    <form method="POST" action="{{ route('documents.verify.post') }}" id="form-ref" style="display:none;">
        @csrf
        <input type="hidden" name="mode" value="fingerprint">
        <div class="fg">
            <label for="fingerprint">Certification reference</label>
            <input type="text" id="fingerprint" name="fingerprint"
                   value="{{ old('fingerprint') }}"
                   placeholder="SHA-256 fingerprint or certification reference ID"
                   style="font-family:monospace;font-size:12px;">
            <div class="tip">Paste the reference from a previously certified document.</div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg" onclick="this.textContent='Verifying…'">Verify reference →</button>
    </form>
</div>

{{-- Error --}}
@if(isset($error) && $error)
<div class="alert alert-error">
    <span class="alert-icon">✕</span>
    <div><strong>Verification error:</strong> {{ $error }}</div>
</div>
@endif

{{-- Result --}}
@if(isset($result))

    @if(!($result['found'] ?? false))

    {{-- Not found --}}
    <div class="result-banner" style="background:var(--red-bg);border:1px solid var(--red-bd);">
        <div class="result-icon" style="background:var(--red);">✕</div>
        <div>
            <div class="result-title" style="color:#991b1b;">Document not recognised</div>
            <div class="result-sub" style="color:#b91c1c;">
                No record matching this document was found.
                The document may not have been certified, or may have been altered since certification.
            </div>
        </div>
    </div>

    @else

    @php
        $doc   = $result['document']   ?? [];
        $chain = $result['blockchain'] ?? [];
        $ts    = isset($doc['timestamp'])
            ? (strlen((string)$doc['timestamp'])>10 ? intdiv($doc['timestamp'],1000) : $doc['timestamp'])
            : null;
    @endphp

    {{-- Found --}}
    <div class="result-banner" style="background:var(--green-bg);border:1px solid var(--green-bd);">
        <div class="result-icon" style="background:var(--green);">✓</div>
        <div>
            <div class="result-title" style="color:#065f46;">Document authentic</div>
            <div class="result-sub" style="color:#047857;">
                This document has been officially certified and its integrity is verified.
            </div>
        </div>
    </div>

    <div class="g2" style="gap:14px;align-items:start;">

        <div class="card">
            <div class="card-head">
                <div class="card-ico ico-green">✓</div>
                <div><div class="card-title">Certification details</div></div>
            </div>

            <div class="drow"><span class="dlabel">Document</span><span class="dvalue" style="font-weight:600;">{{ $doc['name'] ?? '—' }}</span></div>
            <div class="drow"><span class="dlabel">Type</span><span class="dvalue"><span class="badge bg-slate">{{ ucfirst($doc['type'] ?? '—') }}</span>@if($doc['isPhysical']??false)<span class="badge bg-indigo" style="margin-left:4px;">QR sealed</span>@endif</span></div>
            <div class="drow"><span class="dlabel">Issued by</span><span class="dvalue">{{ $doc['institution'] ?? '—' }}</span></div>
            <div class="drow"><span class="dlabel">Status</span><span class="dvalue"><span class="badge bg-green">✓ {{ ucfirst($doc['status'] ?? 'certified') }}</span></span></div>
            @if($ts)<div class="drow"><span class="dlabel">Certified on</span><span class="dvalue">{{ date('d M Y H:i',$ts) }}</span></div>@endif
            <div class="drow" style="border:none;"><span class="dlabel">Integrity</span><span class="dvalue"><span class="badge bg-green">✓ Unaltered</span></span></div>
        </div>

        <div class="card">
            <div class="card-head">
                <div class="card-ico ico-indigo">⛓</div>
                <div><div class="card-title">Anchoring proof</div></div>
            </div>
            <div class="drow"><span class="dlabel">Anchored</span><span class="dvalue"><span class="badge {{ ($chain['anchored']??false)?'bg-green':'bg-amber' }}">{{ ($chain['anchored']??false)?'✓ Confirmed':'⏳ Pending' }}</span></span></div>
            <div class="drow" style="border:none;"><span class="dlabel">Reference ID</span><span class="dvalue mono">{{ $doc['id'] ?? '—' }}</span></div>
        </div>

    </div>

    @endif
@endif

@endsection

@push('scripts')
<script>
function switchTab(tab) {
    document.getElementById('form-file').style.display = tab==='file' ? 'block' : 'none';
    document.getElementById('form-ref').style.display  = tab==='ref'  ? 'block' : 'none';
    document.querySelectorAll('.tab').forEach((t,i) => t.classList.toggle('on', (i===0&&tab==='file')||(i===1&&tab==='ref')));
}
</script>
@endpush
