@extends('layouts.app')
@section('title','Dashboard')
@section('content')

<div class="page-header">
    <h1 class="page-title">Dashboard</h1>
    <p class="page-sub">AuthDocChain SDK — Laravel integration overview</p>
</div>

@if(!config('services.authdocchain.api_key'))
<div class="alert alert-warning">
    <span class="alert-icon">⚠</span>
    <div><strong>API key not configured.</strong>
    Add <code>AUTHDOCCHAIN_API_KEY=adc_live_...</code> to your <code>.env</code>, then run <code>php artisan config:clear</code>.</div>
</div>
@endif

@if($account)
@php
    $quota   = $account['quota'] ?? [];
    $used    = $quota['monthly_certifications_used']  ?? 0;
    $limit   = $quota['monthly_certifications_limit'] ?? 0;
    $unlim   = $limit === 'unlimited';
    $remain  = $quota['remaining']     ?? 0;
    $plan    = ucfirst($quota['plan']  ?? 'starter');
    $days    = $quota['daysRemaining'] ?? null;
    $pct     = (!$unlim && $limit > 0) ? min(100, round($used / $limit * 100)) : 0;
@endphp

<div class="g4" style="margin-bottom:16px;">
    <div class="stat">
        <div class="stat-label">Plan</div>
        <div class="stat-value" style="font-size:18px;color:var(--indigo);">{{ $plan }}</div>
        @if($days !== null)<div class="stat-sub">{{ $days }}d remaining</div>@endif
    </div>
    <div class="stat">
        <div class="stat-label">Used</div>
        <div class="stat-value">{{ $used }}</div>
        <div class="stat-sub">certifications this month</div>
    </div>
    <div class="stat">
        <div class="stat-label">Remaining</div>
        <div class="stat-value">{{ $unlim ? '∞' : $remain }}</div>
        <div class="stat-sub">of {{ $unlim ? '∞' : $limit }}</div>
    </div>
    <div class="stat">
        <div class="stat-label">Total documents</div>
        <div class="stat-value">{{ $documents['pagination']['total'] ?? 0 }}</div>
        <div class="stat-sub">on your account</div>
    </div>
</div>

@if(!$unlim && $limit > 0)
<div class="card" style="padding:14px 20px;margin-bottom:14px;">
    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:7px;">
        <span>Monthly quota</span>
        <span style="font-weight:600;">{{ $used }} / {{ $limit }}</span>
    </div>
    <div class="prog">
        <div class="prog-fill {{ $pct>85?'danger':($pct>65?'warn':'') }}" style="width:{{ $pct }}%"></div>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-top:5px;">
        <span>Resets {{ $quota['resetDate'] ?? '' }}</span>
        <span>{{ $pct }}% used</span>
    </div>
</div>
@endif
@endif

{{-- Quick actions --}}
<div class="g2" style="margin-bottom:14px;">
    <div class="card">
        <div class="card-head">
            <div class="card-ico ico-indigo">✦</div>
            <div>
                <div class="card-title">Certify a document</div>
                <div class="card-desc">Create a permanent, tamper-proof record</div>
            </div>
        </div>
        <p style="font-size:13px;color:var(--muted);margin-bottom:14px;line-height:1.6;">
            Upload a PDF, PNG or JPG. The server verifies document integrity before anchoring.
            Optionally embed a <strong>tamper-proof QR seal</strong> for physical verification.
        </p>
        <a href="{{ route('documents.certify') }}" class="btn btn-primary">Certify a document →</a>
    </div>

    <div class="card">
        <div class="card-head">
            <div class="card-ico ico-green">✓</div>
            <div>
                <div class="card-title">Verify a document</div>
                <div class="card-desc">Check authenticity by file upload or reference</div>
            </div>
        </div>
        <p style="font-size:13px;color:var(--muted);margin-bottom:14px;line-height:1.6;">
            Upload the document directly — the fingerprint is computed server-side,
            keeping your verification workflow fully private.
        </p>
        <a href="{{ route('documents.verify') }}" class="btn btn-secondary">Verify a document →</a>
    </div>
</div>

{{-- Recent documents --}}
<div class="card">
    <div class="card-head">
        <div class="card-ico ico-slate">☰</div>
        <div><div class="card-title">Recent documents</div><div class="card-desc">Last 10 certified documents</div></div>
        <a href="{{ route('documents.list') }}" class="btn btn-ghost" style="margin-left:auto;">View all →</a>
    </div>

    @if(empty($documents['documents']))
        <div class="empty"><div class="empty-icon">📄</div><h3>No documents yet</h3><p>Certify your first document to see it here.</p></div>
    @else
    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Type</th><th>Status</th><th>Seal</th><th>Date</th></tr></thead>
            <tbody>
            @foreach($documents['documents'] as $doc)
            @php
                $ts = isset($doc['timestamp']) ? (strlen((string)$doc['timestamp'])>10 ? intdiv($doc['timestamp'],1000) : $doc['timestamp']) : null;
            @endphp
            <tr>
                <td style="font-weight:500;">{{ $doc['name'] ?? '—' }}</td>
                <td><span class="badge bg-slate">{{ $doc['type'] ?? '—' }}</span></td>
                <td>
                    @if(($doc['status']??'')==='certified')
                        <span class="badge bg-green">✓ Certified</span>
                    @else
                        <span class="badge bg-amber">⏳ Pending</span>
                    @endif
                </td>
                <td>
                    @if($doc['isPhysical']??false)
                        <span class="badge bg-indigo">QR</span>
                    @else
                        <span style="color:var(--border);">—</span>
                    @endif
                </td>
                <td style="color:var(--muted);white-space:nowrap;">{{ $ts ? date('d M Y',$ts) : '—' }}</td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @endif
</div>

@endsection
