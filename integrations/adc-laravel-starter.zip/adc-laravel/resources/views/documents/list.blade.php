@extends('layouts.app')
@section('title','Documents')
@section('content')

<div class="page-header" style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
        <h1 class="page-title">Documents</h1>
        <p class="page-sub">{{ $pagination['total'] ?? 0 }} certified documents on your account</p>
    </div>
    <a href="{{ route('documents.certify') }}" class="btn btn-primary">+ Certify new</a>
</div>

<div class="card">
    @if(empty($documents))
        <div class="empty"><div class="empty-icon">📄</div><h3>No documents yet</h3><p>Certify your first document to see it here.</p></div>
    @else
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Name</th><th>Type</th><th>Status</th><th>Seal</th><th>Anchored</th><th>Date</th><th></th>
                </tr>
            </thead>
            <tbody>
            @foreach($documents as $doc)
            @php
                $ts = isset($doc['timestamp']) ? (strlen((string)$doc['timestamp'])>10 ? intdiv($doc['timestamp'],1000) : $doc['timestamp']) : null;
            @endphp
            <tr>
                <td style="font-weight:500;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $doc['name'] ?? '—' }}</td>
                <td><span class="badge bg-slate">{{ $doc['type'] ?? '—' }}</span></td>
                <td>
                    @if(($doc['status']??'')==='certified')
                        <span class="badge bg-green">✓ Certified</span>
                    @else
                        <span class="badge bg-amber">⏳ Pending</span>
                    @endif
                </td>
                <td>
                    @if($doc['isPhysical']??false)
                        <span class="badge bg-indigo">QR</span>
                    @else
                        <span style="color:var(--border);">—</span>
                    @endif
                </td>
                <td>
                    @if($doc['blockchain']['anchored'] ?? ($doc['txId']??null))
                        <span class="badge bg-green">✓</span>
                    @else
                        <span class="badge bg-amber">⏳</span>
                    @endif
                </td>
                <td style="white-space:nowrap;color:var(--muted);">{{ $ts ? date('d M Y',$ts) : '—' }}</td>
                <td>
                    <a href="{{ route('documents.verify') }}" class="btn btn-ghost" style="font-size:11px;padding:3px 9px;">Verify</a>
                </td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    @if($totalPages > 1)
    <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <span style="font-size:12px;color:var(--muted);">Page {{ $page }} of {{ $totalPages }}</span>
        <div class="pag">
            @if($page>1)<a href="{{ route('documents.list',['page'=>$page-1]) }}" class="pag-btn">← Prev</a>@endif
            @for($i=max(1,$page-2);$i<=min($totalPages,$page+2);$i++)
                <a href="{{ route('documents.list',['page'=>$i]) }}" class="pag-btn {{ $i===$page?'on':'' }}">{{ $i }}</a>
            @endfor
            @if($page<$totalPages)<a href="{{ route('documents.list',['page'=>$page+1]) }}" class="pag-btn">Next →</a>@endif
        </div>
    </div>
    @endif
    @endif
</div>

@endsection
