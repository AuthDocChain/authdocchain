@extends('layouts.app')
@section('title','Certification Result')
@section('content')

@php
    $doc   = $result['document']   ?? [];
    $chain = $result['blockchain'] ?? [];
    $quota = $result['quota']      ?? [];
    $ts    = isset($doc['timestamp'])
        ? (strlen((string)$doc['timestamp'])>10 ? intdiv($doc['timestamp'],1000) : $doc['timestamp'])
        : null;
    $ok = ($doc['status'] ?? '') === 'certified';
@endphp

<div class="page-header">
    <h1 class="page-title">Document certified</h1>
    <p class="page-sub">A permanent record has been created successfully</p>
</div>

<div class="result-banner" style="background:{{ $ok?'var(--green-bg)':'var(--amber-bg)' }};border:1px solid {{ $ok?'var(--green-bd)':'var(--amber-bd)' }};">
    <div class="result-icon" style="background:{{ $ok?'var(--green)':'var(--amber)' }};">
        {{ $ok ? '✓' : '⏳' }}
    </div>
    <div>
        <div class="result-title" style="color:{{ $ok?'#065f46':'#92400e' }};">
            {{ $ok ? 'Record anchored and confirmed' : 'Record created — anchoring in progress' }}
        </div>
        <div class="result-sub" style="color:{{ $ok?'#047857':'#b45309' }};">
            {{ $ok
                ? 'The document fingerprint is permanently recorded and verifiable.'
                : 'The document is registered. Blockchain anchoring will complete shortly.' }}
        </div>
    </div>
</div>

<div class="g2" style="gap:16px;align-items:start;">

    <div class="card">
        <div class="card-head">
            <div class="card-ico ico-indigo">📄</div>
            <div><div class="card-title">Document</div></div>
        </div>

        <div class="drow"><span class="dlabel">Name</span><span class="dvalue" style="font-weight:600;">{{ $doc['name'] ?? '—' }}</span></div>
        <div class="drow"><span class="dlabel">Type</span><span class="dvalue"><span class="badge bg-slate">{{ ucfirst($doc['type'] ?? '—') }}</span>@if($doc['isPhysical']??false)<span class="badge bg-indigo" style="margin-left:4px;">QR sealed</span>@endif</span></div>
        <div class="drow"><span class="dlabel">Issued by</span><span class="dvalue">{{ $doc['institution'] ?? '—' }}</span></div>
        <div class="drow"><span class="dlabel">Status</span><span class="dvalue"><span class="badge {{ $ok?'bg-green':'bg-amber' }}">{{ $ok?'✓ Certified':'⏳ Pending' }}</span></span></div>
        @if($ts)<div class="drow"><span class="dlabel">Certified</span><span class="dvalue">{{ date('d M Y H:i',$ts) }}</span></div>@endif
        @if($doc['isPhysical']??false)<div class="drow"><span class="dlabel">Seal position</span><span class="dvalue">{{ $doc['qrPosition'] ?? '—' }}</span></div>@endif
    </div>

    <div>
        <div class="card" style="margin-bottom:12px;">
            <div class="card-head">
                <div class="card-ico ico-green">⛓</div>
                <div><div class="card-title">Anchoring</div></div>
            </div>
            <div class="drow"><span class="dlabel">Status</span><span class="dvalue"><span class="badge {{ ($chain['anchored']??false)?'bg-green':'bg-amber' }}">{{ ($chain['anchored']??false)?'✓ Confirmed':'⏳ Pending' }}</span></span></div>
            <div class="drow" style="border:none;"><span class="dlabel">Reference ID</span><span class="dvalue mono">{{ $doc['id'] ?? '—' }}</span></div>
        </div>

        @if(!empty($quota))
        <div class="stat">
            <div class="stat-label">Quota remaining</div>
            <div class="stat-value" style="font-size:20px;">{{ ($quota['remaining']==='unlimited')?'∞':$quota['remaining'] }}</div>
            <div class="stat-sub">{{ $quota['used'] }} used of {{ ($quota['limit']==='unlimited')?'∞':$quota['limit'] }}</div>
        </div>
        @endif
    </div>

</div>

@if($doc['isPhysical']??false)
<div class="alert alert-success" style="margin-top:16px;">
    <span class="alert-icon">↓</span>
    <div>
        <strong>Sealed PDF downloaded.</strong>
        The QR-sealed version was streamed directly to your browser — it was never stored on the server,
        consistent with AuthDocChain's zero-storage guarantee.
    </div>
</div>
@endif

<div style="margin-top:20px;display:flex;gap:10px;flex-wrap:wrap;">
    <a href="{{ route('documents.certify') }}" class="btn btn-primary">Certify another document</a>
    <a href="{{ route('documents.verify') }}" class="btn btn-secondary">Verify a document</a>
    <a href="{{ route('documents.list') }}" class="btn btn-ghost">View all documents</a>
</div>

@endsection
