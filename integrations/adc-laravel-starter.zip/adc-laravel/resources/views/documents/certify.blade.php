@extends('layouts.app')
@section('title','Certify')
@section('content')

<div class="page-header">
    <h1 class="page-title">Certify a document</h1>
    <p class="page-sub">Create a permanent, verifiable record for any document</p>
</div>

@if($errors->any())
<div class="alert alert-error">
    <span class="alert-icon">✕</span>
    <div>@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>
</div>
@endif

<form method="POST" action="{{ route('documents.certify.post') }}" enctype="multipart/form-data">
@csrf
<div class="g2" style="gap:18px;align-items:start;">

    {{-- Left: file + metadata --}}
    <div class="card">
        <div class="card-head">
            <div class="card-ico ico-indigo">↑</div>
            <div><div class="card-title">Document</div><div class="card-desc">PDF, PNG or JPG — max 20 MB</div></div>
        </div>

        <div class="fg">
            <label for="document">File</label>
            <input type="file" id="document" name="document" accept=".pdf,.png,.jpg,.jpeg" required onchange="onFile(this)">
            <div class="tip" id="file-hint" style="display:none;"></div>
        </div>

        <div class="fg">
            <label for="name">Document name <span class="opt">(defaults to filename)</span></label>
            <input type="text" id="name" name="name" value="{{ old('name') }}" placeholder="e.g. Diploma 2025 — Alice Martin">
        </div>

        <div class="fg">
            <label for="type">Document type</label>
            <select id="type" name="type" required>
                <option value="" disabled {{ old('type') ? '' : 'selected' }}>Select a type…</option>
                @foreach(['diploma','certificate','contract','invoice','report','identity','other'] as $t)
                    <option value="{{ $t }}" {{ old('type')===$t?'selected':'' }}>{{ ucfirst($t) }}</option>
                @endforeach
            </select>
        </div>
    </div>

    {{-- Right: QR options --}}
    <div class="card">
        <div class="card-head">
            <div class="card-ico ico-amber">▦</div>
            <div><div class="card-title">Verification seal</div><div class="card-desc">Embed a tamper-proof QR in the PDF</div></div>
        </div>

        <div class="fg">
            <label class="cb-row" id="cb-physical-wrap">
                <input type="checkbox" id="physical" name="physical" value="1" onchange="toggleQr(this)" {{ old('physical')?'checked':'' }}>
                <div>
                    <div class="cb-label">Enable QR seal</div>
                    <div class="cb-desc">Returns a sealed PDF — streamed directly, never stored</div>
                </div>
            </label>
        </div>

        <div class="qr-panel {{ old('physical')?'show':'' }}" id="qr-panel">
            <div class="qr-panel-title">Seal options</div>

            <div class="fg">
                <label>Position on page</label>
                <div class="pos-grid" id="pos-grid">
                    @php $sel = old('qr_position','bottom-right');
                    $pos = ['top-left'=>'Top left','top-center'=>'Top center','top-right'=>'Top right',
                            'bottom-left'=>'Bottom left','bottom-center'=>'Bottom center','bottom-right'=>'Bottom right'];
                    @endphp
                    @foreach($pos as $v => $l)
                        <button type="button" class="pos-btn {{ $sel===$v?'on':'' }}" onclick="setPos('{{ $v }}')">{{ $l }}</button>
                    @endforeach
                </div>
                <input type="hidden" id="qr_position" name="qr_position" value="{{ $sel }}">
            </div>

            <div class="div"></div>

            <div class="fg">
                <label for="qr_size">Size — <span id="sz-val">{{ old('qr_size',60) }}</span> pt</label>
                <input type="range" id="qr_size" name="qr_size" min="30" max="80" step="5" value="{{ old('qr_size',60) }}"
                       oninput="document.getElementById('sz-val').textContent=this.value">
                <div class="tip">30 pt (compact) → 80 pt (large)</div>
            </div>

            <div class="fg" style="margin-bottom:0;">
                <label class="cb-row" id="cb-all-wrap">
                    <input type="checkbox" name="stamp_all_pages" value="1" {{ old('stamp_all_pages')?'checked':'' }}>
                    <div>
                        <div class="cb-label">Stamp all pages</div>
                        <div class="cb-desc">Default: first page only</div>
                    </div>
                </label>
            </div>
        </div>

        <div class="alert alert-info" style="margin-top:14px;margin-bottom:0;">
            <span class="alert-icon">ℹ</span>
            <div style="font-size:12px;">
                Document integrity is verified server-side before any record is created.
                Re-certifying an already-sealed document is blocked automatically.
            </div>
        </div>
    </div>
</div>

<div style="margin-top:18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <button type="submit" class="btn btn-primary btn-lg" id="submit-btn">
        <span id="submit-lbl">Certify document</span>
        <span id="submit-spin" style="display:none;">Certifying…</span>
    </button>
    <a href="{{ route('documents.index') }}" class="btn btn-ghost">Cancel</a>
    <span id="submit-tip" style="font-size:12px;color:var(--muted);">Uses 1 certification from your monthly quota.</span>
</div>
</form>

@endsection

@push('scripts')
<script>
function toggleQr(cb) {
    document.getElementById('qr-panel').classList.toggle('show', cb.checked);
    document.getElementById('cb-physical-wrap').classList.toggle('checked', cb.checked);
}
function setPos(val) {
    document.getElementById('qr_position').value = val;
    const vals = ['top-left','top-center','top-right','bottom-left','bottom-center','bottom-right'];
    document.querySelectorAll('#pos-grid .pos-btn').forEach((b,i) => b.classList.toggle('on', vals[i]===val));
}
function onFile(input) {
    const hint = document.getElementById('file-hint');
    if (input.files.length) {
        const f = input.files[0];
        hint.textContent = f.name + ' — ' + (f.size/1024/1024).toFixed(2) + ' MB';
        hint.style.display = 'block';
        if (!document.getElementById('name').value)
            document.getElementById('name').value = f.name.replace(/\.[^/.]+$/,'');
    }
}
document.querySelector('form').addEventListener('submit', () => {
    document.getElementById('submit-lbl').style.display  = 'none';
    document.getElementById('submit-spin').style.display = 'inline';
    document.getElementById('submit-btn').disabled = true;
    document.getElementById('submit-tip').textContent = 'Uploading and creating record — this may take a few seconds…';
});
</script>
@endpush
