<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'AuthDocChain') — SDK Starter</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --indigo:    #4f46e5;
            --indigo-h:  #4338ca;
            --dark:      #0f172a;
            --body:      #334155;
            --muted:     #64748b;
            --border:    #e2e8f0;
            --bg:        #f8fafc;
            --white:     #ffffff;
            --green:     #059669;
            --green-bg:  #f0fdf4;
            --green-bd:  #bbf7d0;
            --red:       #dc2626;
            --red-bg:    #fef2f2;
            --red-bd:    #fecaca;
            --amber:     #d97706;
            --amber-bg:  #fffbeb;
            --amber-bd:  #fde68a;
            --r:         10px;
            --r-sm:      7px;
            --sh:        0 1px 3px rgba(0,0,0,.07), 0 1px 2px rgba(0,0,0,.04);
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            background: var(--bg);
            color: var(--body);
            font-size: 14px;
            line-height: 1.6;
            min-height: 100vh;
        }

        /* ── Nav ── */
        .nav {
            background: var(--white);
            border-bottom: 1px solid var(--border);
            height: 58px;
            padding: 0 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 9px;
            font-weight: 700;
            font-size: 15px;
            letter-spacing: -.4px;
            text-decoration: none;
            color: var(--dark);
        }

        .nav-brand span { color: var(--indigo); }

        .nav-pill {
            font-size: 10px;
            font-weight: 600;
            background: #ede9fe;
            color: var(--indigo);
            padding: 2px 8px;
            border-radius: 20px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 2px;
            list-style: none;
        }

        .nav-links a {
            padding: 6px 13px;
            border-radius: var(--r-sm);
            text-decoration: none;
            color: var(--muted);
            font-size: 13px;
            font-weight: 500;
            transition: background .12s, color .12s;
        }

        .nav-links a:hover { background: var(--bg); color: var(--dark); }
        .nav-links a.active { color: var(--indigo); font-weight: 600; }

        /* ── Page ── */
        .page { max-width: 900px; margin: 0 auto; padding: 32px 20px 72px; }

        .page-header { margin-bottom: 24px; }
        .page-title { font-size: 20px; font-weight: 700; letter-spacing: -.4px; color: var(--dark); }
        .page-sub { color: var(--muted); font-size: 13px; margin-top: 3px; }

        /* ── Alert ── */
        .alert {
            padding: 12px 16px;
            border-radius: var(--r-sm);
            font-size: 13px;
            display: flex;
            gap: 10px;
            align-items: flex-start;
            margin-bottom: 16px;
            border: 1px solid transparent;
        }
        .alert-icon { flex-shrink: 0; font-size: 15px; margin-top: 1px; }
        .alert-error   { background: var(--red-bg);   border-color: var(--red-bd);   color: #991b1b; }
        .alert-success { background: var(--green-bg); border-color: var(--green-bd); color: #166534; }
        .alert-warning { background: var(--amber-bg); border-color: var(--amber-bd); color: #92400e; }
        .alert-info    { background: #eff6ff;          border-color: #bfdbfe;         color: #1e40af; }

        /* ── Card ── */
        .card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--r);
            padding: 20px 24px;
            box-shadow: var(--sh);
        }
        .card + .card { margin-top: 14px; }

        .card-head {
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 16px;
            margin-bottom: 18px;
            border-bottom: 1px solid var(--border);
        }

        .card-ico {
            width: 34px; height: 34px;
            border-radius: var(--r-sm);
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; flex-shrink: 0;
        }
        .ico-indigo { background: #ede9fe; color: var(--indigo); }
        .ico-green  { background: #d1fae5; color: var(--green); }
        .ico-amber  { background: #fef3c7; color: var(--amber); }
        .ico-slate  { background: #f1f5f9; color: var(--muted); }

        .card-title { font-size: 14px; font-weight: 600; color: var(--dark); }
        .card-desc  { font-size: 12px; color: var(--muted); margin-top: 1px; }

        /* ── Grid ── */
        .g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .g3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
        .g4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
        @media(max-width:640px) { .g2,.g3,.g4 { grid-template-columns:1fr; } }

        /* ── Form ── */
        .fg { margin-bottom: 16px; }
        .fg:last-child { margin-bottom: 0; }

        label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 5px;
        }
        label .opt { font-weight: 400; color: var(--muted); }

        input[type=text], select, textarea {
            width: 100%;
            padding: 8px 11px;
            border: 1px solid var(--border);
            border-radius: var(--r-sm);
            font-size: 13px;
            color: var(--dark);
            background: var(--white);
            outline: none;
            transition: border-color .12s, box-shadow .12s;
            appearance: none;
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--indigo);
            box-shadow: 0 0 0 3px rgba(79,70,229,.1);
        }

        input[type=file] {
            width: 100%;
            padding: 9px 12px;
            border: 2px dashed var(--border);
            border-radius: var(--r-sm);
            font-size: 13px;
            color: var(--muted);
            background: var(--bg);
            cursor: pointer;
            transition: border-color .12s;
        }
        input[type=file]:hover { border-color: var(--indigo); }

        input[type=range] { width:100%; accent-color: var(--indigo); }

        .cb-row {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            padding: 10px 13px;
            border: 1px solid var(--border);
            border-radius: var(--r-sm);
            cursor: pointer;
            transition: border-color .12s, background .12s;
        }
        .cb-row input[type=checkbox] { accent-color:var(--indigo); margin-top:2px; flex-shrink:0; }
        .cb-row.checked { border-color: var(--indigo); background: #faf9ff; }
        .cb-label { font-size: 13px; font-weight: 500; color: var(--dark); }
        .cb-desc  { font-size: 12px; color: var(--muted); }

        /* ── Buttons ── */
        .btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 8px 18px; border-radius: var(--r-sm);
            font-size: 13px; font-weight: 600;
            border: none; cursor: pointer;
            text-decoration: none;
            transition: background .12s, transform .1s;
        }
        .btn:active { transform: scale(.98); }
        .btn-primary   { background: var(--indigo);  color: #fff; }
        .btn-primary:hover { background: var(--indigo-h); }
        .btn-secondary { background: var(--white); color: var(--dark); border: 1px solid var(--border); }
        .btn-secondary:hover { background: var(--bg); }
        .btn-ghost { background: transparent; color: var(--muted); padding: 6px 11px; border: 1px solid transparent; }
        .btn-ghost:hover { background: var(--bg); border-color: var(--border); }
        .btn-lg { padding: 10px 24px; font-size: 14px; }

        /* ── Badge ── */
        .badge {
            display: inline-flex; align-items: center; gap: 3px;
            padding: 2px 7px; border-radius: 20px;
            font-size: 11px; font-weight: 600;
        }
        .bg-green  { background:#d1fae5; color:#065f46; }
        .bg-indigo { background:#ede9fe; color:#4338ca; }
        .bg-amber  { background:#fef3c7; color:#92400e; }
        .bg-slate  { background:#f1f5f9; color:#475569; }
        .bg-red    { background:#fef2f2; color:#991b1b; }

        /* ── Stat ── */
        .stat {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--r);
            padding: 14px 18px;
        }
        .stat-label { font-size: 11px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; margin-bottom: 5px; }
        .stat-value { font-size: 24px; font-weight: 700; letter-spacing: -1px; color: var(--dark); }
        .stat-sub   { font-size: 11px; color: var(--muted); margin-top: 2px; }

        /* ── Progress ── */
        .prog { background: var(--border); border-radius: 20px; height: 5px; overflow: hidden; }
        .prog-fill { height: 100%; background: var(--indigo); border-radius: 20px; transition: width .3s; }
        .prog-fill.warn   { background: var(--amber); }
        .prog-fill.danger { background: var(--red); }

        /* ── Table ── */
        .table-wrap { overflow-x: auto; border-radius: var(--r-sm); border: 1px solid var(--border); }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { padding: 9px 13px; text-align: left; background: var(--bg); font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); border-bottom: 1px solid var(--border); }
        td { padding: 10px 13px; border-bottom: 1px solid var(--border); }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #fafbfc; }
        .mono { font-family: 'SF Mono','Fira Code',monospace; font-size: 11px; color: var(--muted); }

        /* ── Detail row ── */
        .drow { display:flex; justify-content:space-between; align-items:flex-start; padding:9px 0; border-bottom:1px solid var(--border); gap:12px; }
        .drow:last-child { border:none; }
        .dlabel { font-size:12px; font-weight:600; color:var(--muted); flex-shrink:0; }
        .dvalue { font-size:13px; color:var(--dark); text-align:right; word-break:break-all; }

        /* ── QR panel ── */
        .qr-panel { border:1px solid var(--border); border-radius:var(--r-sm); padding:16px; background:var(--bg); margin-top:12px; display:none; }
        .qr-panel.show { display:block; }
        .qr-panel-title { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:var(--indigo); margin-bottom:13px; }

        .pos-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:5px; max-width:230px; }
        .pos-btn { padding:6px 4px; border:1px solid var(--border); border-radius:var(--r-sm); background:var(--white); font-size:11px; color:var(--muted); cursor:pointer; text-align:center; transition:border-color .12s,background .12s; }
        .pos-btn.on { border-color:var(--indigo); background:#ede9fe; color:var(--indigo); font-weight:600; }

        /* ── Tab switcher ── */
        .tabs { display:flex; gap:4px; background:var(--bg); border:1px solid var(--border); border-radius:var(--r-sm); padding:4px; margin-bottom:18px; }
        .tab { flex:1; padding:7px; border:none; border-radius:6px; background:transparent; font-size:13px; font-weight:500; color:var(--muted); cursor:pointer; transition:background .12s,color .12s; }
        .tab.on { background:var(--white); color:var(--dark); font-weight:600; box-shadow:var(--sh); }

        /* ── Empty state ── */
        .empty { text-align:center; padding:40px 20px; color:var(--muted); }
        .empty-icon { font-size:32px; margin-bottom:10px; opacity:.4; }
        .empty h3 { font-size:14px; font-weight:600; color:var(--dark); margin-bottom:5px; }

        /* ── Divider ── */
        .div { height:1px; background:var(--border); margin:16px 0; }

        /* ── Tip ── */
        .tip { font-size:11px; color:var(--muted); margin-top:4px; }

        /* ── Pagination ── */
        .pag { display:flex; align-items:center; gap:5px; flex-wrap:wrap; }
        .pag-btn { padding:4px 11px; border:1px solid var(--border); border-radius:var(--r-sm); background:var(--white); font-size:13px; cursor:pointer; text-decoration:none; color:var(--dark); }
        .pag-btn:hover { background:var(--bg); }
        .pag-btn.on { background:var(--indigo); color:#fff; border-color:var(--indigo); }
        .pag-btn.off { opacity:.4; pointer-events:none; }

        /* ── Result success ── */
        .result-banner {
            display:flex; align-items:center; gap:18px;
            padding:20px 24px; border-radius:var(--r);
            margin-bottom:18px;
        }
        .result-icon {
            width:48px; height:48px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-size:22px; color:#fff; flex-shrink:0;
        }
        .result-title { font-size:17px; font-weight:700; }
        .result-sub   { font-size:13px; margin-top:2px; }
    </style>
</head>
<body>

<nav class="nav">
    <a href="{{ route('documents.index') }}" class="nav-brand">
        <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
            <rect width="26" height="26" rx="7" fill="#0f172a"/>
            <path d="M13 4L20 7.5V14c0 4.5-3.5 8-7 10C9.5 22 6 18.5 6 14V7.5L13 4Z"
                  fill="none" stroke="#818cf8" stroke-width="1.5" stroke-linejoin="round"/>
        </svg>
        AuthDoc<span>Chain</span>
        <span class="nav-pill">SDK Starter</span>
    </a>
    <ul class="nav-links">
        <li><a href="{{ route('documents.index') }}"  class="{{ request()->routeIs('documents.index') ? 'active' : '' }}">Dashboard</a></li>
        <li><a href="{{ route('documents.certify') }}" class="{{ request()->routeIs('documents.certify*','documents.result') ? 'active' : '' }}">Certify</a></li>
        <li><a href="{{ route('documents.verify') }}"  class="{{ request()->routeIs('documents.verify*') ? 'active' : '' }}">Verify</a></li>
        <li><a href="{{ route('documents.list') }}"    class="{{ request()->routeIs('documents.list') ? 'active' : '' }}">Documents</a></li>
    </ul>
</nav>

<main class="page">
    @if(session('error'))
        <div class="alert alert-error"><span class="alert-icon">⚠</span><div>{{ session('error') }}</div></div>
    @endif
    @yield('content')
</main>

@stack('scripts')
</body>
</html>
