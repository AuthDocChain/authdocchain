<?php

use App\Http\Controllers\DocumentController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('documents.index'));

Route::prefix('documents')->name('documents.')->group(function () {
    Route::get('/',                [DocumentController::class, 'index']      )->name('index');
    Route::get('/certify',         [DocumentController::class, 'certifyForm'])->name('certify');
    Route::post('/certify',        [DocumentController::class, 'certify']    )->name('certify.post');
    Route::get('/result',          [DocumentController::class, 'result']     )->name('result');
    Route::get('/verify',          [DocumentController::class, 'verifyForm'] )->name('verify');
    Route::post('/verify',         [DocumentController::class, 'verify']     )->name('verify.post');
    Route::get('/list',            [DocumentController::class, 'list']       )->name('list');
});
