<?php

namespace App\Http\Controllers;

use App\Services\AuthDocChainService;
use App\Http\Requests\CertifyRequest;
use App\Http\Requests\VerifyRequest;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class DocumentController extends Controller
{
    public function __construct(
        private readonly AuthDocChainService $adc
    ) {}

    // ── Dashboard ─────────────────────────────────────────────────────────────

    public function index(): View
    {
        try {
            $account   = $this->adc->getAccount();
            $documents = $this->adc->listDocuments(10, 0);
        } catch (\RuntimeException $e) {
            $account   = null;
            $documents = ['documents' => [], 'pagination' => ['total' => 0]];
            session()->flash('error', $e->getMessage());
        }

        return view('documents.index', compact('account', 'documents'));
    }

    // ── Certify ───────────────────────────────────────────────────────────────

    public function certifyForm(): View
    {
        return view('documents.certify');
    }

    public function certify(CertifyRequest $request): mixed
    {
        $file      = $request->file('document');
        $docName   = $request->input('name') ?: $file->getClientOriginalName();
        $docType   = $request->input('type');
        $physical  = $request->boolean('physical');

        try {
            if ($physical) {
                $result = $this->adc->certifyPhysical(
                    filePath:      $file->getPathname(),
                    docName:       $docName,
                    docType:       $docType,
                    qrPosition:    $request->input('qr_position', 'bottom-right'),
                    stampAllPages: $request->boolean('stamp_all_pages'),
                    qrSize:        (int) $request->input('qr_size', 60),
                );

                // If certifiedPdf present → stream directly, no disk write
                if (!empty($result['document']['certifiedPdf'])) {
                    session()->flash('cert_success', [
                        'name'      => $result['document']['name']      ?? $docName,
                        'type'      => $result['document']['type']       ?? $docType,
                        'status'    => $result['document']['status']     ?? null,
                        'anchored'  => $result['blockchain']['anchored'] ?? false,
                        'id'        => $result['document']['id']         ?? null,
                        'timestamp' => $result['document']['timestamp']  ?? null,
                        'isPhysical'=> true,
                        'quota'     => $result['quota']                  ?? [],
                    ]);

                    return $this->adc->streamCertifiedPdf($result, $file->getClientOriginalName());
                }
            } else {
                $result = $this->adc->certifyDocument(
                    filePath: $file->getPathname(),
                    docName:  $docName,
                    docType:  $docType,
                );
            }

            // Strip any base64 blobs before storing in session
            unset($result['document']['certifiedPdf']);

            session()->flash('cert_result', $result);
            return redirect()->route('documents.result');

        } catch (\RuntimeException $e) {
            return back()->withInput()->withErrors(['api' => $e->getMessage()]);
        }
    }

    public function result(): View|RedirectResponse
    {
        if (! session()->has('cert_result')) {
            return redirect()->route('documents.certify');
        }
        $result = session('cert_result');
        return view('documents.result', compact('result'));
    }

    // ── Verify ────────────────────────────────────────────────────────────────

    public function verifyForm(): View
    {
        return view('documents.verify');
    }

    public function verify(VerifyRequest $request): View
    {
        $result = null;
        $error  = null;
        $mode   = $request->input('mode', 'file'); // 'file' | 'fingerprint'

        try {
            if ($mode === 'file' && $request->hasFile('document')) {
                // Compute fingerprint server-side — file never leaves your server
                $result = $this->adc->verifyByFile(
                    $request->file('document')->getPathname()
                );
            } else {
                $result = $this->adc->verifyByFingerprint(
                    $request->input('fingerprint', '')
                );
            }
        } catch (\RuntimeException $e) {
            $error = $e->getMessage();
        }

        return view('documents.verify', compact('result', 'error'));
    }

    // ── Document list ─────────────────────────────────────────────────────────

    public function list(Request $request): View
    {
        $page   = max(1, (int) $request->query('page', 1));
        $limit  = 15;
        $offset = ($page - 1) * $limit;

        try {
            $data = $this->adc->listDocuments($limit, $offset);
        } catch (\RuntimeException $e) {
            $data = ['documents' => [], 'pagination' => ['total' => 0, 'hasMore' => false]];
            session()->flash('error', $e->getMessage());
        }

        $totalPages = (int) ceil(($data['pagination']['total'] ?? 0) / $limit);

        return view('documents.list', [
            'documents'  => $data['documents'] ?? [],
            'pagination' => $data['pagination'] ?? [],
            'page'       => $page,
            'totalPages' => $totalPages,
        ]);
    }
}
